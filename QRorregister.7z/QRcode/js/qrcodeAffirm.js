var obj={};
$(function(){
	find();
	eacheCode(DATA);
	writeIn(obj);
	clickView();
});

//查找邀请码
function eacheCode(data){
	for(var i=0;i<data.length;i++){
		if(obj.name==data[i].name){
			obj.InviteCode=data[i].code;
			return;
		}else{
			$("#InviteCode").addClass("error");
        	$("#InviteCode").val("");
        	$("#InviteCode").attr("placeholder","您没有邀请码，请联系相关人员");
        	closeButton();
       }	
	}
}

//写入内容
function writeIn(obj){
	if(!$("#InviteCode").hasClass("error")){
		$("#InviteCode").val(obj.InviteCode);
	}
	$("#name").val(obj.name);
	$("#tel").val(obj.tel);
}

//click操作
function clickView(){
	//按钮提交
	$("button").click(function(){
		save();
		if(verify()){
			judgeButton(this);
		}else{
			verifyInviteCode($(".InviteCode"));
			verifyName($(".name"));
			verifyTelphone($(".tel"));
		}
	});
}
//客户信息写入方法
   function save(){
        localStorage.setItem("InviteCode",$("#InviteCode").val());
   } 