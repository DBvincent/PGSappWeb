/**Created by ex-dongbo on 2017/4/10*/
var download="http://a.app.qq.com/o/simple.jsp?pkgname=com.dashuf.disp.v2";
var registerData={"cv":"10"};
var headers={"content-type":"application/json"};
var DATA;
$(function(){
    registerData.check="false";
    //获取数据
    getAjax("POST","../../disp-openapi/guest/dictionary/businessCities",headers," ",getBusinessCityData);
    //input 处理
    inputView();
    //click处理
    clickView();
});
//input 处理
function inputView(){
    //tel选择
    $("#tel").focus(function(){
        openButton();
        if($(this).attr("placeholder") == "手机号不能为空"||$(this).attr("placeholder") == "手机号输入有误") {
            $(this).removeClass("error");
            $(this).attr("placeholder","请输入手机号码");
            $(this).val("");
        }
        $(this).attr("type", "tel");
        $(this).css("color", "#666666");
    });
    $("#pass").focus(function(){
        openButton();
        if($(this).attr("placeholder") == "您输入的密码格式有误"||$(this).attr("placeholder") == "密码不能为空") {
            $(this).removeClass("error");
            $(this).attr("placeholder","字母+数字组合，大于等于8位");
            $(this).val("");
        }
        $(this).css("color", "#666666");
    });
    //验证码
    $("#verification").focus(function(){
        openButton();
        if($(this).attr("placeholder") == "验证码错误") {
            $(this).removeClass("error");
            $(this).attr("placeholder","验证码");
            $(this).val("");
        }
        $(this).css("color", "#666666");
    });
    //获取input checked 情况
    $("#choose").focus(function(){
        openButton();
        if($("#choose").is(':checked')){
            data.check="false";
        }else{
            data.check="true";
        }
    });
    //手机号验证
    $("#tel").blur(function(){
        verifyTelphone(this)
    });
    //密码验证
    $("#pass").blur(function(){
        checkPass(this);
    });
    //验证码验证
    $("#verification").blur(function(){
        verifyNumber(this);
    });
}
//click处理
function clickView(){
    //获取验证码
    $("#news").click(function(){
        getAjax("POST","../../disp-openapi/guest/register/passcode",headers,JSON.stringify({"cellphone":$("#tel").val(),"CV":"10"}),getVerificationCode);
    });

    //按钮提交
    $("#btn").click(function(){
        console.log("进入提交");
         if( verify()){
            //获取数据
            getData();
            console.log(data);
            toAjax("POST","../../disp-openapi/guest/register/new",headers,registerData,submitRequest);
        }
    });

    //选择的同行公司插件调用
    popPeer(DATA);


    //常驻城市验证
    $("#city").click(function(){
        $(this).css("color","#666666");
        openButton();
    });

    //选择城市后页面处理
    $("#city").click(function(){
        $(".footer").hide();
    });

}
//数据处理方法
function getData(){
	registerData.username="";
    registerData.cellphone=$("#tel").val();
    registerData.password=$("#pass").val();
    registerData.businessCityCode=$("#city").attr("data-code");
    registerData.passcode=$("#verification").val();
    registerData.requestId=GetQueryString("requestId");
}

//选择的同行公司插件调用
function popPeer(data){
    var area = new LArea();
    area.init({
        'trigger': '#city', //触发选择控件的文本框，同时选择完毕后name属性输出到该位置
        'keys': {
            id: 'code',
            name: 'name'
        }, //绑定数据源相关字段 id对应valueTo的value属性输出 name对应trigger的value属性输出
        'type': 1, //数据源类型
        'data': data, //数据源
        'idx': 1
    });
    // area1.value=[0,0,0];//控制初始位置，注意：该方法并不会影响到input的value
    area.className = ['area_company']; // 设置class值
}

//字母+数字组合，大于等于8位的密码验证
function checkPass(ele){
    var pass=$(ele).val();
    if(!(/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8}$/.test(pass))){
        $(ele).addClass("error");
        $(ele).val("");
        closeButton();
        $(ele).attr("placeholder","您输入的密码格式有误");
    }else if(pass==""){
        $(ele).addClass("error");
        $(ele).val("");
        $(ele).attr("placeholder","密码不能为空");
        closeButton();
    }else{
        $(ele).val(pass);
    }
}
// 手机号验证
function verifyTelphone(ele) {
    var telphone = $(ele).val();
    if(telphone == "") {
        $(ele).addClass("error");
        $(ele).val("");
        $(ele).attr("placeholder","手机号不能为空");
        closeButton();
    } else if(!(/^1[34578]\d{9}$/.test(telphone))) {
        $(ele).addClass("error");
        $(ele).val("");
        $(ele).attr("placeholder","手机号输入有误");
        closeButton();
    } else {
        $(ele).val(telphone);
    }
}
//验证验证码
function verifyNumber(ele){
    var verify=$(ele).val();
    if(verify==""){
        $(ele).addClass("error");
        $(ele).val("");
        $(ele).attr("placeholder","验证码错误");
        closeButton();
    }else{
        $(ele).val(verify)
    }
}
//常驻城市验证
function verifyCity(ele){
    var city=$(ele).html();
    if(city=="请选择"){
        $(ele).html("业务城市不能为空");
        $(ele).css("color","#ef6762");
        closeButton();
    }else{
        $(ele).html(city);
        $(ele).css("color","#666666");
    }
}
//提交验证
function verify(){
    if($("#tel").val() == ""|| $("#pass").val() == ""||$("#verification").val()==""||$("#city").html()=="常驻城市不能为空"){
            verifyTelphone($("#tel"));
            checkPass($("#pass"));
            verifyNumber($("#verification"));
            verifyCity($("#city"));
            closeButton();
            return false;
    }else{
        console.log("填写成功");
         openButton();
          return true;
    }
}
//按钮锁定
function closeButton(){
    $("#btn").attr("disabled","disabled");
    $("#btn").css("background","#d3d3d3");
}
//解锁按钮
function openButton(){
    $("#btn").removeAttr("disabled");
    $("#btn").css("background","#fec43f");
}

//后台报错验证码错误提醒
function errorTip(data,text,timeIn,timeOut){
    $("#layer p").html(text);
    $("#layer").fadeIn(timeIn);
    $("#layer").fadeOut(timeOut);
}

//常驻城市数据获取函数
function getBusinessCityData(data){
    if(data.succeed){
        DATA=data.data;
        DATA.length=DATA.length-1;
        $.map(DATA,function(v){
        	v.name=v.name.split("分公司")[0];
        });
    }else{
        errorTip(data,"服务器开小差，请稍后再试",1000,3500);
    }
}

//短信验证码函数
function getVerificationCode(data){
    if(data.succeed) {
        console.log("OK");
    }else{
        errorTip(data,"您输入的验证码有误",1000,3500);
    }
}

//提交请求处理函数
function submitRequest(data){
	if(data.succeed) {
        console.log("OK");
    }else{
        $("#verification").addClass("error");
        $("#verification").val("");
        $("#verification").attr("placeholder","验证码错误");
    }
}
//后台ajax获取方法
function getAjax(type,URL,headers,DATA,responseFun){
     $.ajax({
        type:type,
        url:URL,
        headers:headers,
        data:DATA,
        success:function(data){
             responseFun(data);
        },
        error:function(error){
            errorTip(error,"服务器开小差，请稍后再试",1000,300000);
        }
    });
}
//后台ajax方法
function toAjax(type,URL,headers,DATA,responseFun){
    $.ajax({
        type:type,
        url:URL,
        headers:headers,
        data:JSON.stringify(DATA),
        success:function(data){
			responseFun(data);
        },
        error:function(error){
            errorTip(error,"服务器开小差，请稍后再试",1000,300000);
        }
    });
}
// 获取产品邀请码
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
    var r = window.location.search.substr(1).match(reg);
    if (r!=null) return (r[2]); return null;
}